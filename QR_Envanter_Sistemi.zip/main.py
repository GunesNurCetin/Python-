import tkinter as tk
from tkinter import messagebox, ttk
import pandas as pd
import qrcode
from PIL import Image, ImageTk
import os

if not os.path.exists("envanter.csv"):
    df = pd.DataFrame(columns=["Ürün Adı", "Stok", "Fiyat"])
    df.to_csv("envanter.csv", index=False)

if not os.path.exists("qr_codes"):
    os.mkdir("qr_codes")

class EnvanterApp:
    def __init__(self, root):
        self.root = root
        self.root.title("📦 QR Kodlu Envanter Takip Sistemi")
        self.root.geometry("700x500")
        self.root.configure(bg="#f2f2f2")

        tk.Label(root, text="QR Kodlu Envanter Sistemi", font=("Arial", 18, "bold"), bg="#f2f2f2", fg="#333").pack(pady=10)

        form_frame = tk.Frame(root, bg="#f2f2f2")
        form_frame.pack(pady=10)

        tk.Label(form_frame, text="Ürün Adı:", bg="#f2f2f2").grid(row=0, column=0, padx=5, pady=5)
        self.urun_entry = tk.Entry(form_frame)
        self.urun_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Stok:", bg="#f2f2f2").grid(row=1, column=0, padx=5, pady=5)
        self.stok_entry = tk.Entry(form_frame)
        self.stok_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Fiyat (₺):", bg="#f2f2f2").grid(row=2, column=0, padx=5, pady=5)
        self.fiyat_entry = tk.Entry(form_frame)
        self.fiyat_entry.grid(row=2, column=1, padx=5, pady=5)

        tk.Button(form_frame, text="Ürün Ekle", command=self.urun_ekle, bg="#4CAF50", fg="white").grid(row=3, column=0, columnspan=2, pady=10)

        self.tree = ttk.Treeview(root, columns=("Ürün Adı", "Stok", "Fiyat"), show="headings", height=10)
        self.tree.heading("Ürün Adı", text="Ürün Adı")
        self.tree.heading("Stok", text="Stok")
        self.tree.heading("Fiyat", text="Fiyat (₺)")
        self.tree.pack(pady=10)
        self.verileri_goster()

        tk.Button(root, text="Yenile", command=self.verileri_goster, bg="#2196F3", fg="white").pack(pady=5)

    def urun_ekle(self):
        urun = self.urun_entry.get()
        stok = self.stok_entry.get()
        fiyat = self.fiyat_entry.get()

        if urun == "" or stok == "" or fiyat == "":
            messagebox.showwarning("Uyarı", "Tüm alanları doldurmalısın!")
            return

        try:
            stok = int(stok)
            fiyat = float(fiyat)
        except ValueError:
            messagebox.showerror("Hata", "Stok tam sayı, fiyat sayı olmalı!")
            return

        df = pd.read_csv("envanter.csv")
        yeni_veri = pd.DataFrame([[urun, stok, fiyat]], columns=["Ürün Adı", "Stok", "Fiyat"])
        df = pd.concat([df, yeni_veri], ignore_index=True)
        df.to_csv("envanter.csv", index=False)

        qr = qrcode.make(f"Ürün: {urun}\nStok: {stok}\nFiyat: {fiyat} ₺")
        qr_path = f"qr_codes/{urun}.png"
        qr.save(qr_path)

        messagebox.showinfo("Başarılı", f"{urun} eklendi ve QR kod oluşturuldu!")
        self.verileri_goster()

    def verileri_goster(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        df = pd.read_csv("envanter.csv")
        for i, row in df.iterrows():
            self.tree.insert("", "end", values=(row["Ürün Adı"], row["Stok"], row["Fiyat"]))

root = tk.Tk()
app = EnvanterApp(root)
root.mainloop()
