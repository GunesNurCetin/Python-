# 📦 QR Kodlu Envanter Takip Sistemi

Bu proje, Python ve Tkinter kullanılarak geliştirilmiş bir **envanter takip uygulamasıdır**.  
Her ürün eklendiğinde otomatik olarak **QR kod** oluşturulur ve sistemde saklanır.

## 🚀 Özellikler
- Ürün ekleme, stok ve fiyat belirleme
- Otomatik QR kod üretimi (PNG)
- CSV dosyasıyla veri saklama
- Tkinter arayüzü ile görsel kullanım

## 🧩 Kullanılan Teknolojiler
- Python
- Tkinter
- pandas
- qrcode
- Pillow

## 📂 Klasör Yapısı
```
QR_Envanter_Sistemi/
│
├── main.py
├── envanter.csv
├── qr_codes/
│   └── ürün_adı.png
└── README.md
```

## ▶️ Çalıştırma
```bash
pip install tkinter pillow qrcode pandas
python main.py
```

## 📸 Ekran Görüntüsü
*(Uygulama ekranı: Ürün ekleme ve listeleme arayüzü + QR kod klasörü)*

---

Geliştiren: **Güneş Nur Çetin**
